from .file_processor_strategy import FileProcessorStrategy
# from .ocr_decorator import OCRDecorator
# from .transcription_decorator import TranscriptionDecorator
